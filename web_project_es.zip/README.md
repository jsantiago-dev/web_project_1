# Bienvenido al proyecto web numero 1 del Sprint 2

Es una web estatica, desarrollada para fomentar el estudio y el aprendisaje asi como el material necesario para llevarlo acabo.

Las tecnologias usadas para el desarrollo fueron HTML5, CSS3, CSS3 Flexbox

## Futuro del proyecto

Se realizara mejoras de las animaciones, se revisaran errores que se generen al abrir la web con el buscador Mozilla.
